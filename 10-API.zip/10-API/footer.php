<!-- footer.php -->
</div> <!-- end container -->
<div class="container text-center mb-4">
    <a href="https://github.com/K3ury99" class="btn btn-dark mx-2" style="margin-top: 15px;">Mi GitHub</a>
    <a href="https://www.youtube.com/playlist?list=PLpwu3FlMDKKcMPyi0mcyj5WJSc66yvYOq" class="btn btn-danger mx-2" style="margin-top: 15px;">Mi Youtube</a>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
